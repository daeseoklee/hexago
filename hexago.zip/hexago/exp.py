import pygame
pygame.font.init()
screen=pygame.display.set_mode((500,500))
running=1
while running:
    event=pygame.event.poll()
    if event.type==pygame.QUIT:
        running=0
    elif event.type==pygame.MOUSEMOTION:
        print(event.pos)
    screen.fill((50,40,20))
    myfont=pygame.font.SysFont('Comic Sans MS',30)
    surface=myfont.render('abcde',False,(255,0,0))
    screen.blit(surface,(0,0))
    pygame.display.flip()